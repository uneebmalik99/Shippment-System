@extends('layouts.partials.mainlayout')
@section('body')
    @include('layouts.customer.mainlayout')
@section('profile-body')
@endsection
@endsection
