@extends('layouts.partials.mainlayout')
@section('body')
    @include('layouts.vehicle_information.mainlayout')
@section('profile-body')
@endsection
@endsection