<div>
    <div class="col-5 d-flex">
        <div class="col-md-6 col-12 px-0 py-0 pl-1 billing px-1">
            <button class="text-center form-control border next-style vehicle_navbar" id="general_vehicle_tab">
                <div class="unskew">General</div>
            </button>
        </div>
        <div class="col-md-6 col-12 px-0 py-0 pl-1 billing px-1">
            <button class="text-center form-control border tab_style vehicle_navbar" id="attachments_vehicle_tab">
                <div class="unskew">Attachments</div>
            </button>
        </div>
    </div>
</div>
