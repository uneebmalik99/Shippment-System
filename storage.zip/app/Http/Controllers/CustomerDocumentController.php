<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CustomerDocumentController extends Controller
{
    //
}
