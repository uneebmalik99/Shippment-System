<title>Blue Ocean Shipping</title>
<!-- HTML5 Shim and Respond.js IE9 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
<!-- Meta -->
<meta charset="utf-8">
<meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>" />
<meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>">

<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="Phoenixcoded">
<meta name="keywords"
    content=", Flat ui, Admin , Responsive, Landing, Bootstrap, App, Template, Mobile, iOS, Android, apple, creative app">
<meta name="author" content="Phoenixcoded">

<link href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" rel="stylesheet">
<!-- Favicon icon -->


<link rel="icon" href="<?php echo e(asset('assets/images/favicon.ico'), false); ?>" type="image/x-icon">
<!-- Google font-->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

<script src="https://cdn.ckeditor.com/4.19.1/standard/ckeditor.js"></script>
<!-- Calender css -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/bower_components/fullcalendar/css/fullcalendar.css'), false); ?>">
<link rel="stylesheet" type="text/css"
    href="<?php echo e(asset('assets/bower_components/fullcalendar/css/fullcalendar.print.css'), false); ?>" media='print'>


<!-- Required Fremwork -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/bower_components/bootstrap/css/bootstrap.min.css'), false); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/assets/css/vehicle.css'), false); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/assets/css/admin_profile.css'), false); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/assets/css/notification.css'), false); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/assets/css/master.css'), false); ?>">
<!-- themify-icons line icon -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/icon/themify-icons/themify-icons.css'), false); ?>">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css"
    integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="stylesheet" href="<?php echo e(asset('assets/css/image-uploader.min.css'), false); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/css/datatable.min.css'), false); ?>">
<!--sticky Css-->
<link rel="stylesheet" href="<?php echo e(asset('assets/pages/sticky/css/jquery.postitall.css'), false); ?>" type="text/css"
    media="all">
<link rel="stylesheet" href="<?php echo e(asset('assets/pages/sticky/css/trumbowyg.css'), false); ?>" type="text/css" media="all">
<!-- Switch component css -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/bower_components/switchery/css/switchery.min.css'), false); ?>">
<!-- ico font -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/icon/icofont/css/icofont.css'), false); ?>">
<!-- flag icon framework css -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/pages/flag-icon/flag-icon.min.css'), false); ?>">
<!-- Menu-Search css -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/pages/menu-search/css/component.css'), false); ?>">

<!-- Style.css -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css'), false); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/custom_style.css'), false); ?>">
<!--color css-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/linearicons.css'), false); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/simple-line-icons.css'), false); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/ionicons.css'), false); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/jquery.mCustomScrollbar.css'), false); ?>">

<script src="https://js.upload.io/upload-js/v1"></script>


<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/js/iziToast.min.js"
    integrity="sha512-Zq9o+E00xhhR/7vJ49mxFNJ0KQw1E1TMWkPTxrWcnpfEFDEXgUiwJHIKit93EW/XxE31HSI5GEOW06G6BF1AtA=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/css/iziToast.css"
    integrity="sha512-DIW4FkYTOxjCqRt7oS9BFO+nVOwDL4bzukDyDtMO7crjUZhwpyrWBFroq+IqRe6VnJkTpRAS6nhDvf0w+wHmxg=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
<?php /**PATH C:\xampp\htdocs\Shippment-System\resources\views/layouts/partials/head.blade.php ENDPATH**/ ?>