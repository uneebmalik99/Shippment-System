<?php echo $__env->make('layouts.customer_create.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<form method="POST" id="customer_general_form" enctype="multipart/form-data">
    <div>
        <div class="row my-3">
            <div class="col-sm-6 col-md-3 col-lg-3">
                <div class="tab_card my-3">
                    
                    <div class="col-10 py-3">
                        <div class="text-color" id="general" onclick="slide(this.id)">
                            <svg width="8" height="6" viewBox="0 0 8 6" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.36328L4 4.82148L7 1.36328" stroke="#FF8514" stroke-width="2"
                                    stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            <span class="p-2" style="cursor: pointer">General Information</span>
                        </div>
                    </div>
                    

                    
                    <div id="general_body">
                        <div class="d-flex align-items-center py-2">
                            <label for="name" class="col-6 px-0 font-size font-bold">Name</label>
                            <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                name="name" id="name" value="<?php echo e(@$user['name'], false); ?>">
                        </div>
                        <div class="d-flex align-items-center py-2">
                            <label for="username" class="col-6 px-0 font-size font-bold">Username</label>
                            <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                name="username" id="username" value="<?php echo e(@$user['name'], false); ?>">
                        </div>
                        <div class="d-flex align-items-center">
                            <label for="username" class="col-6 px-0 font-size font-bold">Password</label>
                            <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                name="password" id="password" value="<?php echo e(@$user['name'], false); ?>">
                        </div>
                        <div class=" d-flex align-items-center">
                            <input type="hidden" class="form-control-sm border border-0 rounded-pill bg col-6"
                                name="status" id="status" value="1">
                        </div>
                        <div class="d-flex align-items-center">
                            <label for="phone" class="px-0 col-6 font-size font-bold">Main phone</label>
                            <input type="phone" class="form-control-sm border border-0 rounded-pill col-6"
                                name="phone" id="phone" value="<?php echo e(@$user['phone'], false); ?>">
                        </div>

                        <div class=" d-flex align-items-center my-4">
                            <label for="fax" class="col-6 px-0 font-size font-bold">Main fax</label>
                            <input type="fax" class="form-control-sm border border-0 rounded-pill bg col-6"
                                name="fax" id="fax" value="<?php echo e(@$user['fax'], false); ?>">
                        </div>
                        <div class=" d-flex align-items-center">
                            <label for="email" class="col-6 px-0 font-size font-bold">Email</label>
                            <input type="email" class="form-control-sm border border-0 rounded-pill bg col-6"
                                name="email" id="email" value="<?php echo e(@$user['email'], false); ?>">
                        </div>
                        <div class="d-flex justify-content-end">
                            <span class="text-danger">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message, false); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>
                        </div>

                        <div class=" d-flex align-items-center">
                            <label for="source" class="col-6 px-0 font-size font-bold">Source</label>
                            <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                name="source" id="source" value="<?php echo e(@$user['source'], false); ?>">
                        </div>
                        <div class="d-flex justify-content-end">
                            <span class="text-danger">
                                <?php $__errorArgs = ['source'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message, false); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>
                        </div>
                        <div class=" d-flex align-items-center">
                            <label for="company_name" class="col-6 px-0 font-size font-bold">Company Name</label>
                            <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                name="company_name" id="company_name" value="<?php echo e(@$user['company_name'], false); ?>">
                        </div>

                        <div class=" d-flex align-items-center my-3">
                            <label for="company_email" class="col-6 px-0 font-size font-bold">Company Email</label>
                            <input type="email" class="form-control-sm border border-0 rounded-pill bg col-6"
                                name="company_email" id="company_email" value="<?php echo e(@$user['company_email'], false); ?>">
                        </div>


                        <div class=" d-flex align-items-center">
                            <label for="customer_type" class="col-6 px-0 font-size font-bold">Customer
                                Type</label>
                            <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                name="customer_type" id="customer_type" value="<?php echo e(@$user['customer_type'], false); ?>">
                        </div>
                        <div class="d-flex justify-content-end">
                            <span class="text-danger">
                                <?php $__errorArgs = ['customer_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message, false); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>
                        </div>

                        <div class=" d-flex align-items-center">
                            <label for="sales_type" class="col-6 px-0 font-size font-bold">Sales Type</label>
                            <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                name="sales_type" id="sales_type" value="<?php echo e(@$user['sales_type'], false); ?>">
                        </div>
                        <div class="d-flex justify-content-end">
                            <span class="text-danger">
                                <?php $__errorArgs = ['sales_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message, false); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>
                        </div>



                    </div>
                    
                </div>
            </div>
            

            <div class="col-sm-6 col-md-3 col-lg-3">
                <div class="tab_card px-2">
                    
                    <div class="py-2 px-3">
                        <div class="text-color px-3" id="sales_application" onclick="slide(this.id)">
                            <svg width="8" height="6" viewBox="0 0 8 6" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.36328L4 4.82148L7 1.36328" stroke="#FF8514" stroke-width="2"
                                    stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            <span class="p-2" style="cursor:pointer">Sales Application</span>
                        </div>
                    </div>
                    



                    
                    <div id="sales_application_body" class="">
                        <div class="pb-3 px-2">
                            <div class="d-flex align-items-center py-2">
                                <label for="sales_person" class="col-6 px-0 font-size font-bold">Sales person</label>
                                <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                    name="sales_person" id="sales_person" value="<?php echo e(@$user['sales_person'], false); ?>">
                            </div>
                            <div class="d-flex justify-content-end">
                                <span class="text-danger">
                                    <?php $__errorArgs = ['sales_person'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message, false); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>

                            <div class="d-flex align-items-center py-2">
                                <label for="inside_person" class="col-6 px-0 font-size font-bold">Inside
                                    person</label>
                                <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                    name="inside_person" id="inside_person" value="<?php echo e(@$user['address_line1'], false); ?>">
                            </div>

                            <div class="d-flex align-items-center py-2">
                                <label for="level" class="col-6 px-0 font-size font-bold">Level</label>
                                <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                    name="level" id="level" value="<?php echo e(@$user['level'], false); ?>">
                            </div>
                        </div>
                    </div>

                    

                </div>
                <div class="tab_card px-2">
                    
                    <div class="py-2">
                        <div class="text-color" id="financial" onclick="slide(this.id)">
                            <svg width="8" height="6" viewBox="0 0 8 6" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.36328L4 4.82148L7 1.36328" stroke="#FF8514" stroke-width="2"
                                    stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            <span class="p-2" style="cursor:pointer">Financial Information</span>
                        </div>
                    </div>
                    
                    
                    <div id="financial_body">

                        <div class="pb-3 px-2">
                            <div class="d-flex align-items-center py-2">
                                <label for="payment_type" class="col-6 px-0 font-size font-bold">Payment Type</label>
                                <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                    name="payment_type" id="payment_type" value="<?php echo e(@$user['payment_type'], false); ?>">
                            </div>

                            <div class="d-flex align-items-center py-2">
                                <label for="payment_term" class="col-6 px-0 font-size font-bold">Payment Term</label>
                                <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                    name="payment_term" id="payment_term" value="<?php echo e(@$user['payment_term'], false); ?>">
                            </div>


                            <div class=" d-flex align-items-center">
                                <label for="industry" class="col-6 px-0 font-size font-bold">Industry</label>
                                <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                    name="industry" id="industry" value="<?php echo e(@$user['industry'], false); ?>">
                            </div>
                            <div class="d-flex justify-content-end">
                                <span class="text-danger">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message, false); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>
                        </div>



                    </div>
                    
                </div>
            </div>
            

            <div class="col-sm-6 col-md-3 col-lg-3 px-3">
                <div class="tab_card px-2">
                    
                    <div class="py-2">
                        <div class="text-color" id="sale_association" onclick="slide(this.id)">
                            <svg width="8" height="6" viewBox="0 0 8 6" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.36328L4 4.82148L7 1.36328" stroke="#FF8514" stroke-width="2"
                                    stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            <span class="p-2 ">Sales Association</span>
                        </div>
                    </div>
                    


                    

                    <div id="sale_association_body">
                        <div class="pb-3 px-2">

                            <div class="d-flex align-items-center py-2">
                                <label for="location_number" class="col-6 px-0 font-size font-bold">Location
                                    Number</label>
                                <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                    name="location_number" id="location_number"
                                    value="<?php echo e(@$user['location_number'], false); ?>">
                            </div>

                            <div class="d-flex align-items-center py-2">
                                <label for="country" class="col-6 px-0 font-size font-bold">Country</label>
                                <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                    name="country" id="country" value="<?php echo e(@$user['country'], false); ?>">
                            </div>
                            <div class="d-flex justify-content-end">
                                <span class="text-danger">
                                    <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message, false); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>

                            <div class="d-flex align-items-center py-2">
                                <label for="zip_code" class="col-6 px-0 font-size font-bold">Zip code</label>
                                <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                    name="zip_code" id="zip_code" value="<?php echo e(@$user['zip_code'], false); ?>">
                            </div>
                            <div class="d-flex justify-content-end">
                                <span class="text-danger">
                                    <?php $__errorArgs = ['zip_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message, false); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>

                            <div class="d-flex align-items-center py-2">
                                <label for="state" class="col-6 px-0 font-size font-bold">State</label>
                                <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                    name="state" id="state" value="<?php echo e(@$user['state'], false); ?>">
                            </div>
                            <div class="d-flex justify-content-end">
                                <span class="text-danger">
                                    <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message, false); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>

                            <div class="d-flex align-items-center py-2">
                                <label for="address_line1" class="col-6 px-0 font-size font-bold">Address (1)</label>
                                <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                    name="address_line1" id="address_line1" value="<?php echo e(@$user['address_line1'], false); ?>">
                            </div>
                            <div class="d-flex justify-content-end">
                                <span class="text-danger">
                                    <?php $__errorArgs = ['address_line1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message, false); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>

                            <div class="d-flex align-items-center py-2">
                                <label for="address_line2" class="col-6 px-0 font-size font-bold">Address (2)</label>
                                <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                    name="address_line2" id="address_line2" value="<?php echo e(@$user['address_line2'], false); ?>">
                            </div>
                            <div class="d-flex justify-content-end">
                                <span class="text-danger">
                                    <?php $__errorArgs = ['address_line2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message, false); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>
                            <div class="d-flex align-items-center py-2">
                                <label for="price_code" class="col-6 px-0 font-size font-bold">Price code</label>
                                <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                    name="price_code" id="price_code" value="<?php echo e(@$user['city'], false); ?>">
                            </div>

                        </div>


                    </div>
                    
                </div>

            </div>
            <div class="col-sm-6 col-md-3 col-lg-3 px-3">
                <div class="col-12">

                    <div class="user_image" style="padding-top: .5rem; border-radius: 15px!important;">
                    </div>
                </div>
                <div class="col-12">
                    <input type="file" name="user_file[]"
                        class="form-control border border-info rounded col-12 w-100" id="user_file">
                </div>

            </div>
        </div>

        <div class="row">
            <div class="col-12 py-2 px-5 d-flex justify-content-end">
                
                <input type="hidden" class="form-control-sm border border-0 rounded-pill bg col-6"
                    name="added_by_user" id="added_by_user" readonly value="<?php echo e(Auth::user()->id, false); ?>">

                <input type="hidden" class="form-control-sm border border-0 rounded-pill bg col-6" name="role_id"
                    id="role_id" readonly value="4">

                <button type="button" class="btn col-1 next-style text-white " onclick="createForm(this.id)"
                    id="general_customer" name="<?php echo e($module['button'], false); ?>" style="padding: 0px;"
                    data-next="billing_customer_tab">
                    <div class="unskew">Next</div>
                </button>
            </div>

        </div>
    </div>

</form>
<?php /**PATH C:\xampp\htdocs\Shippment-System\resources\views/layouts/customer_create/general.blade.php ENDPATH**/ ?>