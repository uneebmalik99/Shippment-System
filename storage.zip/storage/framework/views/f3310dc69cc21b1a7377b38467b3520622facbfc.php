<?php echo $__env->make('layouts.vehicle_create.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form method="POST" id="vehicle_form" enctype="multipart/form-data">
    <div class="d-lg-flex">
        <div class="col-xl-8 col-12 d-lg-flex p-0">
            <div class="col-lg-6 col-12 p-0">
                <div class="col-12">
                    <div class="tab_card my-3">
                        <div class="col-4 py-3">
                            <div class="text-color" style="cursor: pointer;" id="client" onclick="slide(this.id)">
                                <svg width="8" height="6" viewBox="0 0 8 6" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 1.36328L4 4.82148L7 1.36328" stroke="#FF8514" stroke-width="2"
                                        stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                                <span class="p-2">Client</span>
                            </div>
                        </div>
                        <div id="client_body">
                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="customer_name" class="col-6 px-0 font-size font-bold">Client
                                        Name</label>
                                    <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="customer_name" id="customer_name" value="<?php echo e(@$user['customer_name'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="vin" class="col-6 px-0 font-size font-bold">VIN</label>
                                    <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="vin" id="vin" value="<?php echo e(@$user['vin'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['vin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="year" class="col-6 px-0 font-size font-bold">Year</label>
                                    <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="year" id="year" value="<?php echo e(@$user['year'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="make" class="col-6 px-0 font-size font-bold">Make</label>
                                    <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="make" id="make" value="<?php echo e(@$user['make'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['make'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="model" class="col-6 px-0 font-size font-bold">Model</label>
                                    <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="model" id="model" value="<?php echo e(@$user['model'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="vehicle_type" class="col-6 px-0 font-size font-bold">Vehicle
                                        Type</label>
                                    <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="vehicle_type" id="vehicle_type" value="<?php echo e(@$user['vehicle_type'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['vehicle_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="color" class="col-6 px-0 font-size font-bold">Color</label>
                                    <input type="text" class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="color" id="color" value="<?php echo e(@$user['color'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="weight" class="col-6 px-0 font-size font-bold">Weight (Kgs)</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6" name="weight"
                                        id="weight" value="<?php echo e(@$user['weight'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="values" class="col-6 px-0 font-size font-bold">Values</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6" name="value"
                                        id="value" value="<?php echo e(@$user['values'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['values'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="auction" class="col-6 px-0 font-size font-bold">Auction</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6" name="auction"
                                        id="auction" value="<?php echo e(@$user['auction'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['auction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab_card my-3">
                        <div class="col-4 py-3">
                            <div class="text-color" style="cursor: pointer;" id="buyer"
                                onclick="slide(this.id)">
                                <svg width="8" height="6" viewBox="0 0 8 6" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 1.36328L4 4.82148L7 1.36328" stroke="#FF8514" stroke-width="2"
                                        stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                                <span class="p-2">Buyer</span>
                            </div>
                        </div>
                        <div id="buyer_body">
                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="buyer_id" class="col-6 px-0 font-size font-bold">Buyer ID</label>
                                    <select class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="buyer_id" id="buyer_id">
                                        <?php $__currentLoopData = $buyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($buyer['id'], false); ?>"><?php echo e($buyer['name'], false); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['buyer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="keys" class="col-6 px-0 font-size font-bold">Keys</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6" name="key"
                                        id="key" value="<?php echo e(@$user['keys'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['keys'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="notes" class="col-6 px-0 font-size font-bold">Notes</label>
                                    <textarea type="text" class="form-control-sm border border-0 nonrounded-pill bg col-6" name="note"
                                        id="note" value="<?php echo e(@$user['notes'], false); ?>"></textarea>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="title_type" class="col-6 px-0 font-size font-bold">Title Type</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="title_type" id="title_type" value="<?php echo e(@$user['title_type'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['title_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>
                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="hat_number" class="col-6 px-0 font-size font-bold">Hat No</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="hat_number" id="hat_number" value="<?php echo e(@$user['hat_number'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['hat_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab_card my-3">
                        <div class="col-4 py-3">
                            <div class="text-color" style="cursor: pointer;" id="title"
                                onclick="slide(this.id)">
                                <svg width="8" height="6" viewBox="0 0 8 6" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 1.36328L4 4.82148L7 1.36328" stroke="#FF8514" stroke-width="2"
                                        stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                                <span class="p-2">Title</span>
                            </div>
                        </div>
                        <div id="title_body">
                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="title" class="col-6 px-0 font-size font-bold">Title</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6" name="title"
                                        id="title" value="<?php echo e(@$user['title'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="title_rec_date" class="col-6 px-0 font-size font-bold">Title Rec
                                        Date</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="title_rec_date" id="title_rec_date"
                                        value="<?php echo e(@$user['title_rec_date'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['title_rec_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="title_state" class="col-6 px-0 font-size font-bold">Title
                                        State</label>
                                    <select class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="title_state" id="title_state">
                                        <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($locations['id'], false); ?>"><?php echo e($locations['name'], false); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['title_state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="title_number" class="col-6 px-0 font-size font-bold">Title No</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="title_number" id="title_number" value="<?php echo e(@$user['title_number'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['title_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-lg-6 col-12 p-0">

                <div class="col-12">
                    <div class="tab_card my-3">
                        <div class="col-4 py-3">
                            <div class="text-color" style="cursor: pointer;" id="shipper"
                                onclick="slide(this.id)">
                                <svg width="8" height="6" viewBox="0 0 8 6" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 1.36328L4 4.82148L7 1.36328" stroke="#FF8514" stroke-width="2"
                                        stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                                <span class="p-2 ">Shipper</span>
                            </div>
                        </div>
                        <div id="shipper_body">
                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="shipment_id" class="col-6 px-0 font-size font-bold">Shipment
                                        ID</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="shipment_id" id="shipment_id" value="<?php echo e(@$user['shipment_id'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['shipment_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="shipper_name" class="col-6 px-0 font-size font-bold">Shipper
                                        Name</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="shipper_name" id="shipper_name" value="<?php echo e(@$user['shipper_name'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['shipper_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="status" class="col-6 px-0 font-size font-bold">Status</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6" name="status"
                                        id="status" value="<?php echo e(@$user['status'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="sale_date" class="col-6 px-0 font-size font-bold">Sale Date</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6" name="sale_date"
                                        id="sale_date" value="<?php echo e(@$user['sale_date'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['sale_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="paid_date" class="col-6 px-0 font-size font-bold">Paid Date</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6" name="paid_date"
                                        id="paid_date" value="<?php echo e(@$user['paid_date'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['paid_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="days" class="col-6 px-0 font-size font-bold">Days</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6" name="days"
                                        id="days" value="<?php echo e(@$user['days'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="post_date" class="col-6 px-0 font-size font-bold">Post Date</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="posted_date" id="posted_date" value="<?php echo e(@$user['post_date'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['post_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="pickup_date" class="col-6 px-0 font-size font-bold">Pickup
                                        Date</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="pickup_date" id="pickup_date" value="<?php echo e(@$user['pickup_date'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['pickup_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="delivered" class="col-6 px-0 font-size font-bold">Delivered</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6" name="delivered"
                                        id="delivered" value="<?php echo e(@$user['delivered'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['delivered'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="pickup_location" class="col-6 px-0 font-size font-bold">Pickup
                                        Location</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="pickup_location" id="pickup_location"
                                        value="<?php echo e(@$user['pickup_location'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['pickup_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="site" class="col-6 px-0 font-size font-bold">Site</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6" name="site"
                                        id="site" value="<?php echo e(@$user['site'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['site'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>
                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="port" class="col-6 px-0 font-size font-bold">Title
                                        State</label>
                                    <select class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="port" id="port">
                                        <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($locations['id'], false); ?>"><?php echo e($locations['name'], false); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="tab_card my-3">
                        <div class="col-4 py-3">
                            <div class="text-color" style="cursor: pointer;" id="charges"
                                onclick="slide(this.id)">
                                <svg width="8" height="6" viewBox="0 0 8 6" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 1.36328L4 4.82148L7 1.36328" stroke="#FF8514" stroke-width="2"
                                        stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                                <span class="p-2 ">Charges</span>
                            </div>
                        </div>
                        <div id="charges_body">

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="dealer_fee" class="col-6 px-0 font-size font-bold">Dealer Fee</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="dealer_fee" id="dealer_fee" value="<?php echo e(@$user['dealer_fee'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['dealer_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="late_fee" class="col-6 px-0 font-size font-bold">Late Fee</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6" name="late_fee"
                                        id="late_fee" value="<?php echo e(@$user['late_fee'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['late_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="auction_storage" class="col-6 px-0 font-size font-bold">Auction
                                        Storage</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="auction_storage" id="auction_storage"
                                        value="<?php echo e(@$user['auction_storage'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['auction_storage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="towing_charges" class="col-6 px-0 font-size font-bold">Towing
                                        Charges</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="towing_charges" id="towing_charges"
                                        value="<?php echo e(@$user['towing_charges'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['towing_charges'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="title_fee" class="col-6 px-0 font-size font-bold">Title Fee</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6" name="title_fee"
                                        id="title_fee" value="<?php echo e(@$user['title_fee'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['title_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="post_detention" class="col-6 px-0 font-size font-bold">Post
                                        Detention</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="port_detention_fee" id="port_detention_fee"
                                        value="<?php echo e(@$user['post_detention'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['post_detention'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="custom_inspection" class="col-6 px-0 font-size font-bold">Custom
                                        Inspection</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="custom_inspection" id="custom_inspection"
                                        value="<?php echo e(@$user['custom_inspection'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['custom_inspection'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="additional_fee" class="col-6 px-0 font-size font-bold">Additional
                                        Fee</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6"
                                        name="additional_fee" id="additional_fee"
                                        value="<?php echo e(@$user['additional_fee'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['additional_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12 py-2">
                                <div class="d-flex align-items-center">
                                    <label for="insurance" class="col-6 px-0 font-size font-bold">Insurance</label>
                                    <input type="text"
                                        class="form-control-sm border border-0 rounded-pill bg col-6" name="insurance"
                                        id="insurance" value="<?php echo e(@$user['insurance'], false); ?>">
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['insurance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message, false); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="col-lg-4 py-3">
            <div class="col-12">
                <div class="input-images-1 rounded" name="vehicle_image[]" style="padding-top: .5rem;">
                </div>
            </div>
        </div>

    </div>
    <div class="col-12 py-2 px-5 d-flex justify-content-end">

        <input type="hidden" class="form-control-sm border border-0 rounded-pill bg col-6" name="added_by_user"
            id="added_by_user" readonly value="<?php echo e(Auth::user()->id, false); ?>">
        <input type="hidden" readonly name="tab" value="general">
        <button type="submit" class="btn col-1 next-style text-white" onclick="create_vehicle_form(this.id)"
            id="general_vehicle" data-next='attachments_vehicle_tab' name="<?php echo e($module['button'], false); ?>"
            style="cursor: pointer;">
            <div class="unskew">Next</div>
        </button>

    </div>
</form>
<?php /**PATH C:\xampp\htdocs\Shippment-System\resources\views/layouts/vehicle_create/general.blade.php ENDPATH**/ ?>