<form action=<?php echo e($action); ?> method="POST" enctype="multipart/form-data" class="h-100">
    <?php echo csrf_field(); ?>
    <div>
        <div>
            <div class="bg-white">
                <div>
                    <div class="d-flex justify-content-around">
                        <div class="col-4 py-3">
                            <div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="customer_name" class="form-control border border-0 px-0"><b>Client
                                                Name</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text" class="form-control-sm border border-0 rounded-pill bg"
                                            name="customer_name" id="customer_name"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['customer_name'] == null): ?> value="<?php echo e(old('customer_name')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['customer_name']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="vin"
                                            class="form-control border border-0 px-0"><b>VIN</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12" name="vin"
                                            id="vin"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['vin'] == null): ?> value="<?php echo e(old('vin')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['vin']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['vin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="year"
                                            class="form-control border border-0 px-0"><b>Year</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12" name="year"
                                            id="year"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['year'] == null): ?> value="<?php echo e(old('year')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['year']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="make"
                                            class="form-control border border-0 px-0"><b>Make</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12" name="make"
                                            id="make"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['make'] == null): ?> value="<?php echo e(old('make')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['make']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['make'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="model"
                                            class="form-control border border-0 px-0"><b>Model</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12" name="model"
                                            id="model"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['model'] == null): ?> value="<?php echo e(old('model')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['model']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="vehicle_type" class="form-control border border-0 px-0"><b>Vehicle
                                                Type</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="vehicle_type" id="vehicle_type"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['vehicle_type'] == null): ?> value="<?php echo e(old('vehicle_type')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['vehicle_type']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['vehicle_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="color"
                                            class="form-control border border-0 px-0"><b>Color</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12" name="color"
                                            id="color"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['color'] == null): ?> value="<?php echo e(old('color')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['color']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="weight"
                                            class="form-control border border-0 px-0"><b>Weight(Kgs)</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12" name="weight"
                                            id="weight"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['weight'] == null): ?> value="<?php echo e(old('weight')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['weight']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="value"
                                            class="form-control border border-0 px-0"><b>Value($)</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12" name="value"
                                            id="value"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['value'] == null): ?> value="<?php echo e(old('value')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['value']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="auction"
                                            class="form-control border border-0 px-0"><b>Auction</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12" name="auction"
                                            id="auction"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['auction'] == null): ?> value="<?php echo e(old('auction')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['auction']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['auction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="buyer_id" class="form-control border border-0 px-0"><b>Buyer
                                                ID</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <select name="buyer_id" id="buyer_id"
                                            class="form-control-sm border border-0 rounded-pill col-12">
                                            <?php if(\Request::route()->getName() == 'vehicle.edit'): ?>
                                                <option disabled value="<?php echo e(@$vehicle['customer']['id']); ?>">
                                                    <?php echo e(@$vehicle['customer']['id']); ?></option>
                                            <?php endif; ?>

                                            <?php $__currentLoopData = @$buyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(@$buyer['id'] == '2'): ?> selected <?php endif; ?>
                                                    value="<?php echo e(@$buyer['id']); ?>"><?php echo e(@$buyer['id']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['buyer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="key"
                                            class="form-control border border-0 px-0"><b>Keys</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12" name="key"
                                            id="key"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['key'] == null): ?> value="<?php echo e(old('key')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['key']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="note"
                                            class="form-control border border-0 px-0"><b>Notes</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <textarea type="text" class="form-control-sm border border-info rounded" name="note" id="note"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['note'] == null): ?> value="<?php echo e(old('note')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['note']); ?>" <?php endif; ?>></textarea>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="title_type" class="form-control border border-0 px-0"><b>Title
                                                Type</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="title_type" id="title_type"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['title_type'] == null): ?> value="<?php echo e(old('title_type')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['title_type']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['title_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="title"
                                            class="form-control border border-0 px-0"><b>Title</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12" name="title"
                                            id="title"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['title'] == null): ?> value="<?php echo e(old('title')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['title']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="title_rec_date" class="form-control border border-0 px-0"><b>Title
                                                Rec
                                                Date</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="date"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="title_rec_date" id="title_rec_date"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['title_rec_date'] == null): ?> value="<?php echo e(old('title_rec_date')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['title_rec_date']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['title_rec_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="title_state" class="form-control border border-0 px-0"><b>Title
                                                State</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="title_state" id="title_state"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['title_state'] == null): ?> value="<?php echo e(old('title_state')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['title_state']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['title_state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="title_number" class="form-control border border-0 px-0"><b>Title
                                                Number</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="title_number" id="title_number"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['title_number'] == null): ?> value="<?php echo e(old('title_number')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['title_number']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['title_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-4 py-3">
                            <div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="shipper_name" class="form-control border border-0 px-0"><b>Shipper
                                                Name</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text" class="form-control-sm border border-0 rounded-pill bg"
                                            name="shipper_name" id="shipper_name"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['shipper_name'] == null): ?> value="<?php echo e(old('shipper_name')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['shipper_name']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['shipper_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="status"
                                            class="form-control border border-0 px-0"><b>status</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12" name="status"
                                            id="status"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['status'] == null): ?> value="<?php echo e(old('status')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['status']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="sale_date" class="form-control border border-0 px-0"><b>Sale
                                                Date</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="date"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="sale_date" id="sale_date"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['sale_date'] == null): ?> value="<?php echo e(old('sale_date')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['sale_date']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['sale_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="paid_date" class="form-control border border-0 px-0"><b>Paid
                                                Date</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="date"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="paid_date" id="paid_date"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['paid_date'] == null): ?> value="<?php echo e(old('paid_date')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['paid_date']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['make'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="days"
                                            class="form-control border border-0 px-0"><b>Days</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12" name="days"
                                            id="days"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['days'] == null): ?> value="<?php echo e(old('days')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['days']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="post_date" class="form-control border border-0 px-0"><b>Posted
                                                Date</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="date"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="post_date" id="post_date"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['post_date'] == null): ?> value="<?php echo e(old('post_date')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['post_date']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['post_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="pickup_date" class="form-control border border-0 px-0"><b>Pickup
                                                Date</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="date"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="pickup_date" id="pickup_date"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['pickup_date'] == null): ?> value="<?php echo e(old('pickup_date')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['pickup_date']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['pickup_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="delivered"
                                            class="form-control border border-0 px-0"><b>Delivered</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="date"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="delivered" id="delivered"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['delivered'] == null): ?> value="<?php echo e(old('delivered')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['delivered']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['delivered'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="pickup_location"
                                            class="form-control border border-0 px-0"><b>Pickup
                                                Location</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="pickup_location" id="pickup_location"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['pickup_location'] == null): ?> value="<?php echo e(old('pickup_location')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['pickup_location']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['pickup_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="site"
                                            class="form-control border border-0 px-0"><b>Site</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12" name="site"
                                            id="site"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['site'] == null): ?> value="<?php echo e(old('site')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['site']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['site'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="hat_no" class="form-control border border-0 px-0"><b>Hat
                                                Number</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12" name="hat_no"
                                            id="hat_no"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['hat_no'] == null): ?> value="<?php echo e(old('hat_no')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['hat_no']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['hat_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="dealer_fee" class="form-control border border-0 px-0"><b>Dealer
                                                Fee</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="dealer_fee" id="dealer_fee"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['dealer_fee'] == null): ?> value="<?php echo e(old('dealer_fee')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['dealer_fee']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['dealer_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="late_fee" class="form-control border border-0 px-0"><b>Late
                                                Fee</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="late_fee" id="late_fee"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['late_fee'] == null): ?> value="<?php echo e(old('late_fee')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['late_fee']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['late_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="auction_storage"
                                            class="form-control border border-0 px-0"><b>Auction
                                                Storage</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="auction_storage" id="auction_storage"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['auction_storage'] == null): ?> value="<?php echo e(old('auction_storage')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['auction_storage']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['auction_storage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="towing_charges"
                                            class="form-control border border-0 px-0"><b>Towing
                                                Charges</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="towing_charges" id="towing_charges"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['towing_charges'] == null): ?> value="<?php echo e(old('towing_charges')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['towing_charges']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['towing_charges'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="warehouse_storage"
                                            class="form-control border border-0 px-0"><b>Warehouse
                                                Storage</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="warehouse_storage" id="warehouse_storage"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['warehouse_storage'] == null): ?> value="<?php echo e(old('warehouse_storage')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['warehouse_storage']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['warehouse_storage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>

                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="title_fee" class="form-control border border-0 px-0"><b>Title
                                                Fee</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="title_fee" id="title_fee"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['title_fee'] == null): ?> value="<?php echo e(old('title_fee')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['title_fee']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['title_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="port_detention_fee"
                                            class="form-control border border-0 px-0"><b>Port
                                                Detention</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="port_detention_fee" id="port_detention_fee"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['port_detention_fee'] == null): ?> value="<?php echo e(old('port_detention_fee')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['port_detention_fee']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['port_detention_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="custom_inspection"
                                            class="form-control border border-0 px-0"><b>Custom
                                                Inspection</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="custom_inspection" id="custom_inspection"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['custom_inspection'] == null): ?> value="<?php echo e(old('custom_inspection')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['custom_inspection']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['custom_inspection'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="additional_fee"
                                            class="form-control border border-0 px-0"><b>Additional
                                                Fee</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="additional_fee" id="additional_fee"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['additional_fee'] == null): ?> value="<?php echo e(old('additional_fee')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['additional_fee']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['additional_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                                <div class="d-flex py-2">
                                    <div class="col-5 p-0">
                                        <label for="insurance"
                                            class="form-control border border-0 px-0"><b>Insurance</b></label>
                                    </div>
                                    <div class="col-7 p-0">
                                        <input type="text"
                                            class="form-control-sm border border-0 rounded-pill col-12"
                                            name="insurance" id="insurance"
                                            <?php if(\Request::route()->getName() == 'vehicle.create' || @$vehicle['insurance'] == null): ?> value="<?php echo e(old('insurance')); ?>" <?php else: ?> value= "<?php echo e(@$vehicle['insurance']); ?>" <?php endif; ?>>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['insurance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-4 py-3">
                            <div class="col-12">
                                <input type="file" name="image[]"
                                    class="form-control border border-info rounded col-12 w-100" id="fileupload"
                                    multiple="multiple">
                            </div>
                            <div class="d-flex p-2">
                                <div class="d-flex flex-column align-items-center">
                                    <div id="dvPreview1" class="vehicle_image">
                                    </div>
                                    <div><i class="fa fa-trash delete d-none" style="cursor:pointer;"></i></div>
                                </div>
                                <div class="d-flex flex-column align-items-center">
                                    <div id="dvPreview2" class="vehicle_image">
                                    </div>
                                    <div><i class="fa fa-trash delete d-none" style="cursor:pointer;"></i></div>
                                </div>
                            </div>
                            <div class="d-flex p-2">
                                <div class="d-flex flex-column align-items-center">
                                    <div id="dvPreview3" class="vehicle_image">
                                    </div>
                                    <div><i class="fa fa-trash delete d-none" style="cursor:pointer;"></i></div>
                                </div>
                                <div class="d-flex flex-column align-items-center">
                                    <div id="dvPreview4" class="vehicle_image">
                                    </div>
                                    <div><i class="fa fa-trash delete d-none" style="cursor:pointer;"></i></div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="d-flex justify-content-center p-3">
                        <input type="submit" class="btn btn-primary rounded" value="<?php echo e($button_text); ?>">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <input type="hidden" name="added_by_email" value="<?php echo e(Auth::user()->id); ?>">
    <input type="hidden" name="added_by_role" value="<?php echo e(Auth::user()->id); ?>">

</form>
<?php /**PATH C:\xampp\htdocs\Shippment-System\resources\views/layouts/vehicle/general.blade.php ENDPATH**/ ?>