<div>
    <button wire:click="increment">+</button>
    <h1>1</h1>
    <button>-</button>
</div><?php /**PATH C:\xampp\htdocs\Shippment-System\resources\views//livewire/Customer/profile.blade.php ENDPATH**/ ?>