
<?php $__env->startSection('body'); ?>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-fullscreen scrollable mw-100 m-2 px-3 py-2" role="document">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between title_style">
                    <div>
                        <h5 class="modal-title text-white" id="exampleModalLabel">New <?php echo e($module['singular'], false); ?></h5>
                    </div>
                    <div>
                        <button type="button" class="close text-white h6" data-dismiss="modal" aria-label="Close"
                            style="margin-top: -11px;
                        font-size: 26px;">
                            <span aria-hidden="true">x</span>
                        </button>
                    </div>
                </div>
                <div class="modal-body">
                    ...
                </div>
            </div>
        </div>
    </div>
    
    
    
    
    <div class="bg-white rounded p-2">
        
        <div class="d-flex m-2">
            <div class="col-4 p-1">
                <div class="col-12 py-0 px-1">
                    <div class="col-12 border-style card-rounded py-2 px-3">
                        <div class="d-flex">
                            <div class="col-10 text-muted p-0 d-flex align-items-center">
                                <div class="font-size"><span>New Orders</span></div>
                            </div>
                            <div class="col-2 p-2 d-flex justify-content-center align-items-center rounded"
                                style="background: rgba(96, 43, 33, 0.2); !important">
                                <img src="<?php echo e(asset('images/new_order.png'), false); ?>" alt="new order.png   ">

                            </div>
                        </div>
                        <div>
                            <div class="font-bold"><span><?php echo e(@$new_orders->count(), false); ?></span> </div>
                            <div class="py-1 col-12 text-muted p-0 font-size"><span>Total User</span></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-4 p-1">
                <div class="col-12 py-0 px-1">
                    <div class="col-12 border-style card-rounded py-2 px-3">
                        <div class="d-flex">
                            <div class="col-10 text-muted p-0 d-flex align-items-center">
                                <div class="font-size"><span>Posted</span></div>
                            </div>
                            <div class="col-2 p-2 d-flex justify-content-center align-items-center rounded"
                                style="background: rgba(169, 154, 75, 0.2);!important">
                                <img src="<?php echo e(asset('images/posted.png'), false); ?>" alt="posted.png">
                            </div>
                        </div>
                        <div>
                            <div class="font-bold"><span><?php echo e(@$posted->count(), false); ?></span> </div>
                            <div class="py-1 col-12 text-muted p-0 font-size"><span>Last week Analytics</span></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-4 p-1">
                <div class="col-12 py-0 px-1">
                    <div class="col-12 border-style card-rounded py-2 px-3">
                        <div class="d-flex">
                            <div class="col-10 text-muted p-0 d-flex align-items-center">
                                <div class="font-size"><span>Dispatched</span></div>
                            </div>
                            <div class="col-2 p-2 d-flex justify-content-center align-items-center rounded"
                                style="background: rgba(86, 138, 75, 0.2); !important">
                                <img src="<?php echo e(asset('images/dispatched.png'), false); ?>" alt="dispatched.png">

                            </div>
                        </div>
                        <div>
                            <div class="font-bold"><span class="px-1"><?php echo e(@$dispatched->count(), false); ?></span><span
                                    class="percent_size">(-14%)</span>
                            </div>
                            <div class="py-1 col-12 text-muted p-0 font-size"><span>Last week Analytics</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex m-2">
            <div class="col-4 p-1">
                <div class="col-12 py-0 px-1">
                    <div class="col-12 border-style card-rounded py-2 px-3">
                        <div class="d-flex">
                            <div class="col-10 text-muted p-0 d-flex align-items-center">
                                <div class="font-size"><span>On Hand</span></div>
                            </div>
                            <div class="col-2 p-2 d-flex justify-content-center align-items-center rounded"
                                style="background: rgba(0, 150, 136, 0.2); !important">
                                <img src="<?php echo e(asset('images/on_hand.png'), false); ?>" alt="on hand.png">


                            </div>
                        </div>
                        <div>
                            <div class="font-bold"><span><?php echo e(@$on_hand->count(), false); ?></span> </div>
                            <div class="py-1 col-12 text-muted p-0 font-size"><span>Total User</span></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-4 p-1">
                <div class="col-12 py-0 px-1">
                    <div class="col-12 border-style card-rounded py-2 px-3">
                        <div class="d-flex">
                            <div class="col-10 text-muted p-0 d-flex align-items-center">
                                <div class="font-size"><span>No Titles</span></div>
                            </div>
                            <div class="col-2 p-2 d-flex justify-content-center align-items-center rounded"
                                style="background: rgba(36, 40, 219, 0.2);!important">
                                <img src="<?php echo e(asset('images/no_titles.png'), false); ?>" alt="no titles.png">

                            </div>
                        </div>
                        <div>
                            <div class="font-bold"><span><?php echo e(@$no_titles->count(), false); ?></span> </div>
                            <div class="py-1 col-12 text-muted p-0 font-size"><span>Last week Analytics</span></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-4 p-1">
                <div class="col-12 py-0 px-1">
                    <div class="col-12 border-style card-rounded py-2 px-3">
                        <div class="d-flex">
                            <div class="col-10 text-muted p-0 d-flex align-items-center">
                                <div class="font-size"><span>Towing</span></div>
                            </div>
                            <div class="col-2 p-2 d-flex justify-content-center align-items-center rounded"
                                style="background: rgba(236, 184, 0, 0.2); !important">
                                <img src="<?php echo e(asset('images/towing.png'), false); ?>" alt="towing.png">

                            </div>
                        </div>
                        <div>
                            <div class="font-bold"><span class="px-1"><?php echo e(@$towing->count(), false); ?></span><span
                                    class="percent_size">(-14%)</span>
                            </div>
                            <div class="py-1 col-12 text-muted p-0 font-size"><span>Last week Analytics</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        

        
        <div class="px-3 mt-3">
            <div class="border-style card-rounded">
                
                <div class="row d-flex justify-content-between">
                    <div>
                        <?php if(session('success')): ?>
                            <div class="btn alert alert-success m-0">
                                <span><?php echo e(session('success'), false); ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                
                <div class="px-4 pt-2 mt-4">
                    <div class="d-flex justify-content-between">
                        <div class="col-6 p-0">
                            <span class="h5 text-muted">
                                <b>Search Filter</b>
                            </span>
                        </div>
                        <div class="col-6 d-flex justify-content-end p-0">
                            <div class="col-4 d-flex justify-content-end px-2">
                                <a href="<?php echo e(route('vehicle.export'), false); ?>"
                                    class="px-1 text-muted font-size form-contorl-sm border p-1 rounded col-12"
                                    style="background: #DBDBDB; cursor: pointer;">
                                    <div class="d-flex justify-content-center align-items-center px-1">
                                        <svg width="18" height="24" viewBox="0 0 24 24" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path d="M11 16H13V7H16L12 2L8 7H11V16Z" fill="#8F8F8F" />
                                            <path
                                                d="M5 22H19C20.103 22 21 21.103 21 20V11C21 9.897 20.103 9 19 9H15V11H19V20H5V11H9V9H5C3.897 9 3 9.897 3 11V20C3 21.103 3.897 22 5 22Z"
                                                fill="#8F8F8F" />
                                        </svg>
                                        <span class="pl-1 font-size">Export</span>
                                    </div>
                                </a>
                            </div>
                            <div class="col-5 px-0 d-flex justify-content-center">
                                <button type="button"
                                    class="text-white form-control-sm border py-1 btn-info rounded modal_button px-2 col-12"
                                    style="background: #696CFF;" data-target="#exampleModal" id="vehicle">
                                    <div class="d-flex justify-content-center align-items-center">
                                        <a class="text-white d-flex align-items-center">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="24"
                                                fill="white" viewBox="0 0 512 512">
                                                <path
                                                    d="M135.2 117.4L109.1 192H402.9l-26.1-74.6C372.3 104.6 360.2 96 346.6 96H165.4c-13.6 0-25.7 8.6-30.2 21.4zM39.6 196.8L74.8 96.3C88.3 57.8 124.6 32 165.4 32H346.6c40.8 0 77.1 25.8 90.6 64.3l35.2 100.5c23.2 9.6 39.6 32.5 39.6 59.2V400v48c0 17.7-14.3 32-32 32H448c-17.7 0-32-14.3-32-32V400H96v48c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32V400 256c0-26.7 16.4-49.6 39.6-59.2zM128 288c0-17.7-14.3-32-32-32s-32 14.3-32 32s14.3 32 32 32s32-14.3 32-32zm288 32c17.7 0 32-14.3 32-32s-14.3-32-32-32s-32 14.3-32 32s14.3 32 32 32z" />
                                            </svg>
                                            <span class="pl-2 font-size">Add New Vehicle</span></a>
                                    </div>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-flex py-3 px-0">
                        <div class="col-3 p-0">
                            <select
                                class="form-control-sm border-style input-border-style rounded vehicle_filtering col-11 text-muted px-2"
                                name="warehouse" id="vehicle_warehouse">
                                <option value="" disabled selected>WAREHOUSE</option>
                                <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($locations['id'], false); ?>"><?php echo e($locations['name'], false); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-2 p-0">
                            <select
                                class="form-control-sm border-style input-border-style rounded vehicle_filtering col-11 text-muted px-2"
                                name="year" id="vehicle_year">
                                <option value="" disabled selected>YEAR</option>
                                <option value="2019">2019</option>
                                <option value="2020">2020</option>
                            </select>
                        </div>
                        <div class="col-2 p-0">
                            <select
                                class="form-control-sm border-style input-border-style rounded vehicle_filtering col-11 text-muted px-2"
                                name="make" id="vehicle_make">
                                <option value="" disabled selected>MAKE</option>
                                <option value="honda">Honda</option>
                                <option value="toyota">Toyota</option>
                            </select>
                        </div>
                        <div class="col-2 p-0">
                            <select
                                class="form-control-sm border-style input-border-style rounded vehicle_filtering col-11 text-muted px-2"
                                name="model" id="vehicle_model">
                                <option value="" disabled selected>MODEL</option>
                                <option value="civic">Civic</option>
                                <option value="corolla">Corolla</option>
                            </select>
                        </div>
                        <div class="col-3 p-0">
                            <select
                                class="form-control-sm border-style input-border-style rounded vehicle_filtering col-12 text-muted"
                                name="status" id="vehicle_status">
                                <option value="" disabled selected>STATUS</option>
                                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <option value="<?php echo e($stat['id'], false); ?>">
                                        <?php echo e(ucfirst($stat['status_name']), false); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                    </div>
                </div>
                
                <div class="mt-2 bg-light" id="status_body" style="height: 100%;overflow-x: scroll;">

                    <table id="vehicle_table" class="table scroll row-border">
                        <thead class="bg-custom text-dark">
                            <tr class="font-size">
                                <th class="font-bold-tr">Sr</th>
                                <th class="font-bold-tr">Customer Name</th>
                                <th class="font-bold-tr">VIN</th>
                                <th class="font-bold-tr">YEAR</th>
                                <th class="font-bold-tr">MAKE</th>
                                <th class="font-bold-tr">MODEL</th>
                                <th class="font-bold-tr">VEHICLE TYPE</th>
                                <th class="font-bold-tr">VALUE</th>
                                <th class="font-bold-tr">STATUS</th>
                                <th class="font-bold-tr">BUYER</th>
                                <th class="font-bold-tr">ACTION</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white font-size" id="vehicle_tbody">
                            
                            <?php if(@count($records) == 0): ?>
                                <tr class="font-size">
                                    <td colspan="11" class="h5 text-muted text-center">NO VEHICLES TO DISPLAY</td>
                                </tr>
                            <?php endif; ?>
                            <?php $i = 1; ?>
                            <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <tr>
                                    <td><?php echo e(@$i, false); ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div style="vertical-align: middle">
                                                <img src="<?php echo e(asset('images/user.png'), false); ?>" alt=""
                                                    class="customer_image">
                                            </div>
                                            <div>
                                                <?php echo e(@$val['customer_name'], false); ?><br>
                                                <span style="font-size: 12px!important;">
                                                    <?php echo e(@$val['user']['email'], false); ?>


                                                </span>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo e(@$val['vin'], false); ?></td>
                                    <td><?php echo e(@$val['year'], false); ?></td>
                                    <td><?php echo e(@$val['make'], false); ?></td>
                                    <td><?php echo e(@$val['model'], false); ?></td>
                                    <td><?php echo e(@$val['vehicle_type'], false); ?></td>
                                    <td><?php echo e(@$val['value'], false); ?></td>
                                    <td><?php echo e(@$val['status'], false); ?></td>
                                    <td><?php echo e(@$val['user']['name'], false); ?></td>
                                    <td>
                                        <button class="profile-button">
                                            <a href=<?php echo e(route('vehicle.profile') . '/' . @$val[@$module['db_key']], false); ?>>
                                                <svg width="14" height="13" viewBox="0 0 16 14" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M16 7C16 7 13 2.1875 8 2.1875C3 2.1875 0 7 0 7C0 7 3 11.8125 8 11.8125C13 11.8125 16 7 16 7ZM1.173 7C1.65651 6.35698 2.21264 5.7581 2.833 5.21237C4.12 4.0845 5.88 3.0625 8 3.0625C10.12 3.0625 11.879 4.0845 13.168 5.21237C13.7884 5.7581 14.3445 6.35698 14.828 7C14.77 7.07613 14.706 7.16013 14.633 7.252C14.298 7.672 13.803 8.232 13.168 8.78763C11.879 9.9155 10.119 10.9375 8 10.9375C5.88 10.9375 4.121 9.9155 2.832 8.78763C2.21165 8.2419 1.65552 7.64301 1.172 7H1.173Z"
                                                        fill="#048B52" />
                                                    <path
                                                        d="M8 4.8125C7.33696 4.8125 6.70107 5.04297 6.23223 5.4532C5.76339 5.86344 5.5 6.41984 5.5 7C5.5 7.58016 5.76339 8.13656 6.23223 8.5468C6.70107 8.95703 7.33696 9.1875 8 9.1875C8.66304 9.1875 9.29893 8.95703 9.76777 8.5468C10.2366 8.13656 10.5 7.58016 10.5 7C10.5 6.41984 10.2366 5.86344 9.76777 5.4532C9.29893 5.04297 8.66304 4.8125 8 4.8125ZM4.5 7C4.5 6.18777 4.86875 5.40882 5.52513 4.83449C6.1815 4.26016 7.07174 3.9375 8 3.9375C8.92826 3.9375 9.8185 4.26016 10.4749 4.83449C11.1313 5.40882 11.5 6.18777 11.5 7C11.5 7.81223 11.1313 8.59118 10.4749 9.16551C9.8185 9.73984 8.92826 10.0625 8 10.0625C7.07174 10.0625 6.1815 9.73984 5.52513 9.16551C4.86875 8.59118 4.5 7.81223 4.5 7Z"
                                                        fill="#048B52" />
                                                </svg>

                                            </a>
                                        </button>
                                        <button class="edit-button">
                                            <a href=<?php echo e(url(@$module['action'] . '/edit/' . @$val[@$module['db_key']]), false); ?>>
                                                <svg width="14" height="13" viewBox="0 0 16 16" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M2.66708 14.0004C2.72022 14.0068 2.77394 14.0068 2.82708 14.0004L5.49375 13.3338C5.61205 13.3056 5.7204 13.2457 5.80708 13.1604L14.0004 4.94042C14.2488 4.69061 14.3881 4.35267 14.3881 4.00042C14.3881 3.64818 14.2488 3.31024 14.0004 3.06042L12.9471 2.00042C12.8233 1.87646 12.6762 1.77811 12.5143 1.71101C12.3525 1.64391 12.179 1.60938 12.0037 1.60938C11.8285 1.60938 11.655 1.64391 11.4932 1.71101C11.3313 1.77811 11.1842 1.87646 11.0604 2.00042L2.86708 10.1938C2.78094 10.2808 2.71891 10.3888 2.68708 10.5071L2.02042 13.1738C1.99645 13.26 1.99011 13.3502 2.00177 13.439C2.01342 13.5277 2.04284 13.6133 2.08826 13.6904C2.13368 13.7676 2.19417 13.8348 2.26613 13.888C2.33808 13.9413 2.42003 13.9795 2.50708 14.0004C2.56022 14.0068 2.61394 14.0068 2.66708 14.0004ZM12.0004 2.94042L13.0604 4.00042L12.0004 5.06042L10.9471 4.00042L12.0004 2.94042ZM3.94042 11.0071L10.0004 4.94042L11.0604 6.00042L4.99375 12.0671L3.58708 12.4138L3.94042 11.0071Z"
                                                        fill="#2C77E7" />
                                                </svg>

                                            </a>
                                        </button>
                                        <button class="delete-button">
                                            <a href=<?php echo e(url(@$module['action'] . '/delete/' . @$val[@$module['db_key']]), false); ?>>
                                                <svg width="14" height="13" viewBox="0 0 12 12" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M5 3H7C7 2.73478 6.89464 2.48043 6.70711 2.29289C6.51957 2.10536 6.26522 2 6 2C5.73478 2 5.48043 2.10536 5.29289 2.29289C5.10536 2.48043 5 2.73478 5 3V3ZM4 3C4 2.46957 4.21071 1.96086 4.58579 1.58579C4.96086 1.21071 5.46957 1 6 1C6.53043 1 7.03914 1.21071 7.41421 1.58579C7.78929 1.96086 8 2.46957 8 3H10.5C10.6326 3 10.7598 3.05268 10.8536 3.14645C10.9473 3.24021 11 3.36739 11 3.5C11 3.63261 10.9473 3.75979 10.8536 3.85355C10.7598 3.94732 10.6326 4 10.5 4H10.059L9.616 9.17C9.57341 9.66923 9.34499 10.1343 8.97593 10.4732C8.60686 10.8121 8.12405 11.0001 7.623 11H4.377C3.87595 11.0001 3.39314 10.8121 3.02407 10.4732C2.65501 10.1343 2.42659 9.66923 2.384 9.17L1.941 4H1.5C1.36739 4 1.24021 3.94732 1.14645 3.85355C1.05268 3.75979 1 3.63261 1 3.5C1 3.36739 1.05268 3.24021 1.14645 3.14645C1.24021 3.05268 1.36739 3 1.5 3H4ZM7.5 6C7.5 5.86739 7.44732 5.74021 7.35355 5.64645C7.25979 5.55268 7.13261 5.5 7 5.5C6.86739 5.5 6.74021 5.55268 6.64645 5.64645C6.55268 5.74021 6.5 5.86739 6.5 6V8C6.5 8.13261 6.55268 8.25979 6.64645 8.35355C6.74021 8.44732 6.86739 8.5 7 8.5C7.13261 8.5 7.25979 8.44732 7.35355 8.35355C7.44732 8.25979 7.5 8.13261 7.5 8V6ZM5 5.5C5.13261 5.5 5.25979 5.55268 5.35355 5.64645C5.44732 5.74021 5.5 5.86739 5.5 6V8C5.5 8.13261 5.44732 8.25979 5.35355 8.35355C5.25979 8.44732 5.13261 8.5 5 8.5C4.86739 8.5 4.74021 8.44732 4.64645 8.35355C4.55268 8.25979 4.5 8.13261 4.5 8V6C4.5 5.86739 4.55268 5.74021 4.64645 5.64645C4.74021 5.55268 4.86739 5.5 5 5.5V5.5ZM3.38 9.085C3.4013 9.3347 3.51558 9.5673 3.70022 9.73676C3.88486 9.90621 4.12639 10.0002 4.377 10H7.623C7.87344 9.9999 8.11472 9.90584 8.29915 9.73642C8.48357 9.56699 8.59771 9.33453 8.619 9.085L9.055 4H2.945L3.381 9.085H3.38Z"
                                                        fill="#EF5757" />
                                                </svg>

                                            </a>
                                        </button>
                                    </td>
                                </tr>
                                <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-end p-2" id="page">
                </div>
            </div>
        </div>
        
    </div>
    

    <script>
        $(".vehicl_navbar_img").click(function() {
            $(".vehicl_navbar_img.active").removeClass('active')
            $(this).addClass('active')
        });

        $(".vehicles_3navbar").click(function() {
            $(".vehicles_3navbar.activee").removeClass('activee')
            $(this).addClass('activee')
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.partials.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Shippment-System\resources\views/vehicle/list.blade.php ENDPATH**/ ?>