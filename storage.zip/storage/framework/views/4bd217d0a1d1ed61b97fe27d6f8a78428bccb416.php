
<div>LiveWire</div><?php /**PATH C:\xampp\htdocs\Shippment-System\resources\views/livewire/Customer/profile.blade.php ENDPATH**/ ?>