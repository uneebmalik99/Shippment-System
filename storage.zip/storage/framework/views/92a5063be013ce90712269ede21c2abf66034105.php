<div class="card simple-cards border-white">
    
    <div class="card-block d-flex">
        
        <?php echo $__env->make('layouts.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        
        <div class="col-9 px-2">
            <?php echo $__env->make('layouts.customer.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="tab_body">
                <?php echo $__env->make('layouts.customer.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <!-- end of row -->
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Shippment-System\resources\views/layouts/customer/mainlayout.blade.php ENDPATH**/ ?>