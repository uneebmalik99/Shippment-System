<div class="col-3 h-100 p-0">
    <div class="col-lg-12 p-0">
        <div class="card user-card rounded">
            <div class="card-header-img">
                <?php if(@$user['user_image']): ?>
                <img class="img-fluid w-50" src="<?php echo e(asset(@$user['user_image']), false); ?>" alt="card-img"/>
                <?php else: ?>
                <img class="img-fluid w-50" src="<?php echo e(asset('assets/images/user.png'), false); ?>" alt="card-img" />
                <?php endif; ?>
                
                <div>
                    <h6 class="mx-0 my-2 text-muted"><b><?php echo e(strtoupper(@$user['customer_name']), false); ?></b></h6>
                    <span class="font-size"><?php echo e(@$user['customer_email'], false); ?></span>
                </div>
            </div>
            
           
            <div>
                <br>
                <div>
                    <span class="text-muted my-3">
                        <b>Username:</b> <?php echo e(@$user['name'], false); ?>

                        </span>
                </div>
                <div class="p-3">
                    
                    <div class="d-flex justify-content-start">
                        <span class="text-muted"><b>Details</b></span>
                    </div>
                    <hr class="m-0" style="border:1px solid #555454">
                </div>
                <div class="d-flex flex-column align-items-start">
                    
                    
                    <span class="text-muted py-1 px-3">
                        <b>Status:</b>
                        
                        <?php if(@$user['status'] == "1"): ?>
                            <div class="badge badge-success py-1 px-2 rounded">Active</div>
                        <?php endif; ?>

                        <?php if(@$user['status'] == '0'): ?>
                            <div class="badge badge-danger py-1 px-2 rounded">In Active</div>
                        <?php endif; ?>
                    </span>
                    <span class="text-muted py-1 px-3">
                        <b>Role:</b> customer
                    </span>
                    <span class="text-muted py-1 px-3">
                        <b>Tax id:</b> <?php echo e(@$user['tax_id'], false); ?> 12
                    </span>
                    <span class="text-muted py-1 px-3">
                        <b>Contact:</b> <?php echo e(@$user['phone'], false); ?>

                    </span>
                    <span class="text-muted py-1 px-3">
                        <b>Country:</b> <?php echo e(@$user['country'], false); ?>

                    </span>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Shippment-System\resources\views/layouts/customer/sidebar.blade.php ENDPATH**/ ?>