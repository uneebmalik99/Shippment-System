<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<title>login</title>
</head>
<style>
	*{
		padding: 0;
		margin: 0;
		box-sizing: border-box;
	}
	.container-fluid{
		width: 100vw!important;
		height: 100vh!important;
		position: relative!important;

	}
	#first_img{
        background: url(<?php echo e('public/images/login_l.png', false); ?>);
        background-repeat: no-repeat;
        background-size:cover;
         background-position:center;
		width: inherit;
		height: 100vh!important;

	}
	#second_img{
		background: url(<?php echo e('public/images/login_r.png', false); ?>);
        background-repeat: no-repeat;
         background-size:cover;
         background-position:center;
		width: inherit;
		height: 100vh!important;

	}
	.login{
		position: absolute!important;
		left: 50%;
		top: 50%;
		transform: translate(-50%, -50%);
		width: 350px;
		height: auto;
		background: white;
        /* box-shadow: 2px 2px 2px rgba(255,255,255,.1);
         */
         border-radius: 10px;
	}
	.login h2{
		text-align: center;
	}
	.login form{
		padding: 15px 22px;
	}
	.login_text{
		position: absolute;
		top: 80%;
		left: 5%;
		
	}
	.login_text b{
		font-size: 22px;
        color: white;
	}
    .copyright{
        position: absolute;
        top:88%;
        right:10%;
    }
    .copyright p{
        text-transform: capitalize;
        font-size:10px;
    color: #EE281F;

    }
    .logo{
        position: absolute;
        / width:35px; /
        z-index: 111;
        top:8%;
        left:6%;
    }
    input{
        box-shadow: none!important;
        outline:none!important;
    }
    input:focus{
        outline: none!important;
        box-shadow: none!important;
    }
@media  screen and (max-width: 768px) {
  .login_text b{
    color: #EE281F;
  }

}
</style>
<body>
	
	<div class="container-fluid" >
        <div class="logo">
            <img src="<?php echo e(asset('images/logo.png'), false); ?>" alt="" width="85px" height="85px">

        </div>
		<div class="row">
			
			<div class="d-none d-sm-none d-md-block col-md-6 col-lg-6" id="first_img">
				
			</div>
			<div class=" col-12 col-sm-12 col-md-6 col-lg-6" id="second_img">
                <div class="copyright">
                    <p>copyright@ 2022 all right reserved <br>
                        Developed by Blue Ocean Shipping</p>
                </div>

                
            </div>

		</div>

		<div class="login shadow" style="box-shadow:
        inset 0 -3em 3em rgba(0,0,0,0.1),
              0 0  0 2px rgb(255,255,255),
              0.3em 0.3em 1em rgba(0,0,0,0.3);">
            <form method="POST" action="<?php echo e(route ('login'), false); ?>">
                <?php echo csrf_field(); ?>
			<h2>Login</h2>

  <div class="form-group">
    <label for="exampleInputEmail1">Email</label>
    <input type="email" class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" name="email" value="<?php echo e(old('email'), false); ?>" required >
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback" role="alert">
    <strong><?php echo e($message, false); ?></strong></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputPassword1" placeholder="Password" name="password">
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback" role="alert">
    <strong><?php echo e($message, false); ?></strong></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  
  <div class="form-group">
  <button type="submit" class="btn btn-primary form-control" style="background:#EE281F;outline:none;border:none">Login</button>
  </div>
  <div class="form-group form-check text-center">
    <input type="checkbox" class="form-check-input" name="remember"
    id="remember" <?php echo e(old('remember') ? 'checked' : '', false); ?>>
    <label class="form-check-label" for="remember">
        <?php echo e(__('Remember Me'), false); ?>

    </label>
  </div>
  <div class="form-group form-check text-center">
    <a href="" style="color:#EE281F">Forgot Password</a>
  </div>
</form>
		</div>


		<div class="login_text">
		<b>Welcome to Blue Ocean Shipping</b>
		</div>

       


	</div>


<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\Shippment-System\resources\views/auth/login.blade.php ENDPATH**/ ?>