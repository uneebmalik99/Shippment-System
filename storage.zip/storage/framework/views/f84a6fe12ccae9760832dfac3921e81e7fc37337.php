<div class="row my-5">
    <div class="col-sm-12 col-md-12 col-lg-12 mx-auto">
        <div class="information_second_div">
            <div class="row" style="padding-bottom:60px">
                <div class="col-sm-12 col-md-5 col-lg-6 mx-auto mb-4">
                    <div class="inspection_heading" style="width:100%">
                        <h6>Notes</h6>
                        <div class="Notes w-100 d-flex">
                            <a href="">Date</a>
                            <a href="">Notes</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12 col-md-7 col-lg-6 mb-4">
                    <div class="information_gallary">
                        <div class="gallary_header d-flex">
                            <div class="w-100">
                                <div class="w-100 d-flex justify-content-center" style="
                                margin: 10px 2px;
                                padding: 0 6px;
                            ">
                                    <button class="img_active_button"><div class="img_button">Vehicle Image</div></button>
                                    <button class="image_button" style="margin-left:22px"><div class="img_button">
                                        Auction Image
                                    </div></button>
                                </div>
                                <div class="w-100 d-flex justify-content-center mt-4">
                                    <button class="image_button mx-auto "><div class="img_button">Ware House Image</div></button>
                                </div>
                            </div>
                            <div class="w-100 d-flex justify-content-center" style="margin:10px 0px">
                                <img src="<?php echo e(asset('images/1.png'), false); ?>" alt=" " style=" width: 160px; height: 88px; ">
                            </div>
                        </div>
                        <div class="gallary_body ">
                            <div class="d-flex flex-wrap justify-content-center ">
                                <div class="img">
                                    <img src="<?php echo e(asset('images/1.png'), false); ?>" alt=" " style="width: 80px; height: 60px; ">
                                </div>
                                <div class="img">
                                    <img src="<?php echo e(asset('images/1.png'), false); ?>" alt=" " style="width: 80px; height: 60px; ">
                                </div>
                                <div class="img ">
                                    <img src="<?php echo e(asset('images/1.png'), false); ?>" alt=" " style="width: 80px; height: 60px; ">
                                </div>
                                <div class="img ">
                                    <img src="<?php echo e(asset('images/1.png'), false); ?>" alt=" " style="width: 80px; height: 60px; ">
                                </div>
                                <div class="img ">
                                    <img src="<?php echo e(asset('images/1.png'), false); ?>" alt=" " style="width: 80px; height: 60px; ">
                                </div>
                                <div class="img ">
                                    <img src="<?php echo e(asset('images/1.png'), false); ?>" alt=" " style="width: 80px; height: 60px; ">
                                </div>
                                <div class="img ">
                                    <img src="<?php echo e(asset('images/1.png'), false); ?>" alt=" " style="width: 80px; height: 60px; ">
                                </div>
                                <div class="img ">
                                    <img src="<?php echo e(asset('images/1.png'), false); ?>" alt=" " style="width: 80px; height: 60px; ">
                                </div>
                                <div class="img ">
                                    <img src="<?php echo e(asset('images/1.png'), false); ?>" alt=" " style="width: 80px; height: 60px; ">
                                </div>
                                <div class="img ">
                                    <img src="<?php echo e(asset('images/1.png'), false); ?>" alt=" " style="width: 80px; height: 60px; ">
                                </div>
                                <div class="img ">
                                    <img src="<?php echo e(asset('images/1.png'), false); ?>" alt=" " style="width: 80px; height: 60px; ">
                                </div>
                                <div class="img ">
                                    <img src="<?php echo e(asset('images/1.png'), false); ?>" alt=" " style="width: 80px; height: 60px; ">
                                </div>
                                <div class="img ">
                                    <img src="<?php echo e(asset('images/1.png'), false); ?>" alt=" " style="width: 80px; height: 60px; ">
                                </div>
                                <div class="img ">
                                    <img src="<?php echo e(asset('images/1.png'), false); ?>" alt=" " style="width: 80px; height: 60px; ">
                                </div>
                                <div class="img ">
                                    <img src="<?php echo e(asset('images/1.png'), false); ?>" alt=" " style="width: 80px; height: 60px; ">
                                </div>
                                <div class="img ">
                                    <img src="<?php echo e(asset('images/1.png'), false); ?>" alt=" " style="width: 80px; height: 60px; ">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-12 d-flex justify-content-center ">
                            <button style="background: rgba(37, 101, 4, 0.72); border-radius: 6px;border:none;color:white;transform: skew(-30deg);">
                                <div style="transform: skew(30deg);padding:1px 10px;font-size: 13px;">
                                Download Images in Zip
                            </div>
                        </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Shippment-System\resources\views/layouts/vehicle_information/notes.blade.php ENDPATH**/ ?>