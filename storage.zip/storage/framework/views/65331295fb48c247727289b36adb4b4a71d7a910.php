<div class="row">
    <div class="col-12 d-flex information_buttons p-0">
        <button class="active_information_button form-control vehicle_information_tab col-3" tab="general"
            id="<?php echo e(@$vehicle['id'], false); ?>">
            <div class="unskew">General</div>
        </button>
        <button class="form-control vehicle_information_tab col-2" tab="inspection" id="<?php echo e(@$vehicle['id'], false); ?>">
            <div class="unskew">Inspection</div>
        </button>
        <button class="form-control vehicle_information_tab col-2" tab="services" id="<?php echo e(@$vehicle['id'], false); ?>">
            <div class="unskew">Services</div>
        </button>
        <button class="form-control vehicle_information_tab col-2" tab="documents" id="<?php echo e(@$vehicle['id'], false); ?>">
            <div class="unskew">Documents</div>
        </button>
        <button class="form-control vehicle_information_tab col-2" tab="notes" id="<?php echo e(@$vehicle['id'], false); ?>">
            <div class="unskew">Notes</div>
        </button>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Shippment-System\resources\views/layouts/vehicle_information/navbar.blade.php ENDPATH**/ ?>