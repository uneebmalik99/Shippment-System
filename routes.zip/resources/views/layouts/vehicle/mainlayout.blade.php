@include('layouts.vehicle.navbar')
@include('layouts.vehicle.attachments')
    