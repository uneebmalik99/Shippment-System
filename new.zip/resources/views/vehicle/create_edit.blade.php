@extends('layouts.partials.mainlayout')
@section('body')
    @include('layouts.vehicle.mainlayout')
@endsection
