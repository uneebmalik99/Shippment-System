@extends('layouts.partials.mainlayout')
@section('body')
  <button><a href="{{ route('notification.create') }}">NEW</a></button>
@endsection
