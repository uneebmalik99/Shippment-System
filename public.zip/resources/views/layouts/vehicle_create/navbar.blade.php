@include('layouts.vehicle_create.navbar')
<div>
    <div class="col-5 d-flex">
        <div class="col-6 px-0 py-0 pl-1 billing">
            <button class="text-center form-control btn border border-info" style="cursor: pointer;" id="general">
                General
            </button>
        </div>
        <div class="col-6 px-0 py-0 pl-1 billing">
            <button class="text-center form-control btn border border-info" style="cursor: pointer;" id="attachments">
                Attachments</button>
        </div>
        <div class="col-6 px-0 py-0 pl-1">
            <button class="text-center form-control btn border border-info" style="cursor: pointer;" id="shipper">
                Shipper
            </button>
        </div>
        <div class="col-6 px-0 py-0 pl-1">
            <button class="text-center form-control btn border border-info" style="cursor: pointer;" id="quotation">
                Quotation
            </button>
        </div>
    </div>
</div>
